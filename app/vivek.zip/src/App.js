import logo from './logo.svg';
import './App.css';
import Navbar from './Navbar/Navbar';
import SideFilter from './SideFilter/SideFilter';
import Footer from './Footer/Footer';
import AllRoute from './MainRouters/AllRoute';
import Home from './pages/Home';
import FetchData from './fetchData/FetchData';
function App() {
  return (
    <div className="App">
     {/* <Navbar/>
     <AllRoute/> */}
     {/* <SideFilter/> */}
     {/* <Home/>
     <Footer/> */}
     <FetchData/>
    </div>
  );
}

export default App;
