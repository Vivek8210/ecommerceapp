import React from 'react'

const Mobile = () => {
  return (
    <div>Mobile</div>
  )
}

export default Mobile