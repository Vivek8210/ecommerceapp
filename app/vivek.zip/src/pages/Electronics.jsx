import React from 'react'

const Electronics = () => {
  return (
    <div>Electronics</div>
  )
}

export default Electronics