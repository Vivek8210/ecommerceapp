import React from 'react'

const HomeAppliance = () => {
  return (
    <div>HomeAppliance</div>
  )
}

export default HomeAppliance